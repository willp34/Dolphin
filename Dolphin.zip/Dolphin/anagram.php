<?php

	if(!isset( $_SERVER["HTTP_X_REQUESTED_WITH"] )){
		die("No Direct Acess");
	}

	if(!isset($_FILES["fileToupload"]["name"])  ){
	 exit("No file selected");
		
	}
	$target_dir ="uploads/";
	$target_file  = $target_dir . basename($_FILES["fileToupload"]["name"]);
	$uploadOK = 1;
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	$result = array();
	$result["errors"]=array();
	if(file_exists($target_file)){
		$result["errors"][]= "Sorry file already exists <br />";
		$uploadOK = 0;
	}
	
	if($_FILES["fileToupload"]["size"] >50000000){
		$result["errors"][]= "Sorry file is too large <br />";
		$uploadOK = 0;
	}
	
	if($imageFileType!="txt"){
			$result["errors"][]= "Sorry only txt files are allowed <br />";
			$uploadOK = 0;
		}
		
	if($uploadOK ==0){
		$result["errors"][]= " Sorry , your file was not uploaded <br />" ;
	}
	else{
		if(move_uploaded_file($_FILES["fileToupload"]["tmp_name"],$target_file )){
			//$result["errors"]= "Ther file ".basename($_FILES["fileToupload"]["name"]). " has been uploaded";
			
			$anogram_collection = new Anagram($result);
			$result = $anogram_collection->messages_ok();
		}
		else{
			$result["errors"][]= "Sorry,there was an error uploading  your file   ". basename($_FILES["fileToupload"]["name"]);
		}
	}
	if(empty($result["errors"]) ){
		unset($result["errors"]);
	}
 echo json_encode($result);
      
	
	class Anagram {
			
		private  $collection_of_anagram = array();
		private $msg_response = array();
		
		function __construct($response){
			 $start_time = time();
			
			$file_to_read= "uploads/".basename($_FILES["fileToupload"]["name"]);
			///$response["errors"] ="File to be uploaded ".$file_to_read;
			
			$response["records"]= $this->read_file($file_to_read,$response);
			$response["content"] = $this->display();
			$execution_time =time() - $start_time;
			$response["execution_time"] = "<h3>Execution time:    $execution_time  seconds</h3>";
			
			$this->set_message($response);
			
		
		}
		/*
		*	This function reads through the file once its been uploaded. 
		*/
		private function read_file($words, $res){
			// Read file line by line
			$anagrams = array();
			$file = fopen($words,"r");
			if($file){
				
				while(($line =fgets($file)) !==false){
					//echo "$line  <br />";
					$word = trim($line);
					$normalize_word= $this->letters_in_aphabetical_order($word);
				//	$count_var = $normalize_word.'_count';
					if(!isset( $anagrams[$normalize_word] ) ){
						$anagrams[$normalize_word]["words"] = array();
						
						$anagrams[$normalize_word]["count"] = 0;
					}
					// keyeep adding words to correct array Ive done this to make it faster when going through the file
					$anagrams[$normalize_word]["words"][] = $word;
					$anagrams[$normalize_word]["count"] = $anagrams[$normalize_word]["count"]+1;
					
					}
				fclose($file);
			
			$this->set_message($res);
			$this->set_anagram( $anagrams); 
			$records = "<h2>Number of Records: ".  count($this->collection_of_anagram) ."</h2> ";
			}else{
				echo "Unable to open file.<br />";
			}
			return $records;
		}
		/**
		* Takes each word and places letters in order. It does this by placing letters in array and sorting them
		*/
		private function letters_in_aphabetical_order($word){
			
			$word_Arr = str_split($word);
			sort($word_Arr);
			return implode('',$word_Arr);
		}
		private function set_message($message_arr){
			$this->msg_response = $message_arr;
		}
		public function messages_ok(){
			return $this->msg_response;
		}
		private function set_anagram($anagram_arr){
			
			$this->collection_of_anagram = array_filter($anagram_arr, function($list){
				return count($list["words"])>1;
			});
			usort($this->collection_of_anagram,function($item1,$item2){
				return $item1["count"]  <=> $item2["count"] ;
			}
			);
		}
		/*
		* Display data in a table and this is shown in tbody
		*/
		private function display()
		{
		
			$content ="";
			//$content.="<h2>Number of Records:". count($this->collection_of_anagram). "</h2>";
			
			
			foreach($this->collection_of_anagram as $a_gram){
				
				 $content	.="<tr><td> ".  $a_gram["count"] ." </td>";
				 $content .= "<td>(  ". implode(', ',$a_gram["words"]) ." ) </td></tr>";
			
			}
			
		
			return $content;
			
		}
		
	}
	
?>