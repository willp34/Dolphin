
<html>
<head>
	<link rel="stylesheet" href="assets/css/bootstrap.css">
</head>
<body>
	
	<div class="container">
			<form action ="anagram.php" method="post" enctype="multipart/form-data" class="process">
				<fieldset>
					<legend> Dolphin </legend>
						<div   class="form-group">
								<label>Select text file </label>
								<input class="form-control-file" type="file" name="fileToupload" id= "fileToupload"   >
						</div>
						<input class="btn  btn-primary" TYPE="submit" value="Upload" name="submit"  >
				</fieldset>
		</form>
		<div  id="results">
				<div id="Dolphin_dialog" ></div>
				 
				<table  class="table">
					<thead>
						<tr>
							<th>Count</th>
							<th>Anagrams</th>
						</tr>
					<thead>
					<tbody id="Dolphin_table_results">
							<tr><td>No data displyed</td></tr>
					</tbody>
				</table>
		</div>
	</div>
	
	
</body>
<script type="text/javascript"  src="assets/js/jquery/jquery.min.js"  > </script>
<script type="text/javascript"  src="assets/js/homepage.js"  > </script>
</html>


