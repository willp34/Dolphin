
jQuery(document).ready(function () {
	
	
	jQuery(".process").on("submit", function(e) {
			e.preventDefault();

			
			var fd = new FormData();
			var files = jQuery("#fileToupload")[0].files[0];
			fd.append('fileToupload',files);
			var action =jQuery(this).attr("action");
		
			 jQuery.ajax({
				 type : jQuery(this).attr("method"),
				 dataType : "json",
				 url : action,
				 data : fd,
				 contentType:false,
				 processData:false,
				 success: function(response) {
						
						
						if(response !=0) {
							//alert(response.like_count);
						if(response.hasOwnProperty("errors")){
							content ='<div class="alert alert-danger " role="alert "> '+response.errors+'</div>';
							jQuery("#results #Dolphin_dialog").append(content);
						}
						if(response.hasOwnProperty("records")){
							content ='<div class="alert alert-success " role="alert "> '+response.records+ ' '+ response.execution_time+ '</div>';
							jQuery("#results #Dolphin_dialog").html("") ;
							jQuery("#results #Dolphin_dialog").append(content);
						}
						if(response.hasOwnProperty("content")){
							content =response.content;
							jQuery("#results #Dolphin_table_results").html(content);
						}		  
						}
						else {
						   alert("Your like could not be added");
						}
				 }
		  });
		  
	  })
	  

});
